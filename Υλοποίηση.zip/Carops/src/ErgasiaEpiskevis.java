public class ErgasiaEpiskevis {
	private String episkevi;
    private int timh;

    public ErgasiaEpiskevis(String episkevi, int timh) {
        this.episkevi = episkevi;
        this.timh = timh;
    }

    public String getEpiskevi() {
        return episkevi;
    }

    public int getTimh() {
        return timh;
    }

}
